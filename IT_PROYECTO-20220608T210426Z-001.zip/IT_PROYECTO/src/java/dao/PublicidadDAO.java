/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.PublicidadClient;
import java.util.List;
import entidades.Publicidad;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author cutit
 */
public class PublicidadDAO {
    
    public static List<Publicidad> getListado() {
        
        PublicidadClient cliente = new PublicidadClient();
        GenericType<List<Publicidad>> tipoGenerico = new GenericType<List<Publicidad>>(){};
        List<Publicidad> datos = cliente.findAll_XML(tipoGenerico);
        
        return datos;
    }
    
    public static void save(Publicidad p) {
        PublicidadClient cliente = new PublicidadClient();
        cliente.create_XML(p);
    }
    
    public static void delete(String id) {
        PublicidadClient cliente = new PublicidadClient();
        cliente.remove(id);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.TemaClient;
import java.util.List;
import entidades.Tema;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author cutit
 */
public class TemaDAO {
    
    private static final String controlador = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/it_proyecto_g9?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String user = "root";
    private static final String clave = "";

    // Cargar driver controlador
    static {
        try {
            Class.forName(controlador);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Error loading JDBC Driver " + "class. Cause: " + ex);
        }
    }
    
    public static List<Tema> getListado() {
        
        TemaClient cliente = new TemaClient();
        GenericType<List<Tema>> tipoGenerico = new GenericType<List<Tema>>(){};
        List<Tema> datos = cliente.findAll_XML(tipoGenerico);
        
        return datos;
    }
    
    //Alta de tema
    public static boolean save(Tema tema) {

        TemaClient cliente = new TemaClient();
        if (tema != null) {
            cliente.create_XML(tema);
            return true;
        } else {
            return false;
        }
    }
    
    //Baja de tema
    public static void delete(String id) throws SQLException {
        // Crear conexion
        Connection conn = DriverManager.getConnection(url, user, clave);
        // Statement
        Statement s = conn.createStatement();
        // Consulta
        String query = "DELETE FROM mensaje WHERE tema_id = " + id;
        s.execute(query);
        
        TemaClient cliente = new TemaClient();
        cliente.remove(id);
    }
    
    public static Tema getTema(String id) {
        List<Tema> temas = getListado();
        Tema tema = null;
        for (int i = 0 ; i < temas.size() ; i++) {
            if (temas.get(i).getId().equals(Integer.parseInt(id))){
                tema = temas.get(i);
            }
        }
        return tema;
    }
    
    public static void update(Tema usuario, String id) {

        TemaClient cliente = new TemaClient();
        cliente.edit_XML(usuario, id);

    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.TransaccionClient;
import entidades.Producto;
import java.util.*;
import javax.ws.rs.core.GenericType;
import entidades.Transacciones;
import entidades.Usuario;

/**
 *
 * @author jucargoe
 */
public class TransaccionDAO {

    public static void crearTransaccion(Producto producto, Usuario usuario, String direccion, String forma_pago) {
        TransaccionClient cliente = new TransaccionClient();
        
        Transacciones tx = new Transacciones();
        tx.setFecha(new Date());
        tx.setFormaPago(forma_pago);
        tx.setDireccion(direccion);
        tx.setImporte((float) producto.getPrecio());
        tx.setProductoId(producto);
        tx.setUsuarioId(usuario);
        
        cliente.create_XML(tx);
    }

    public static List<Transacciones> getListado(int id) {
        TransaccionClient cliente = new TransaccionClient();
        GenericType<List<Transacciones>> tipoGenerico = new GenericType<List<Transacciones>>() {
        };
        List<Transacciones> datos = cliente.findAll_XML(tipoGenerico);

        return datos;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.UsuarioClient;
import entidades.Rol;
import java.util.List;
import entidades.Usuario;
import javax.ws.rs.core.GenericType;
import java.sql.*;

/**
 *
 * @author jucargoe
 */
public class UsuarioDAO {

    private static final String controlador = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/it_proyecto_g9?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String user = "root";
    private static final String clave = "";

    // Cargar driver controlador
    static {
        try {
            Class.forName(controlador);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Error loading JDBC Driver " + "class. Cause: " + ex);
        }
    }

    public static Usuario login(String nick, String password) throws SQLException {

        Usuario usuario = null;

        if (nick != null || password != null) {
            // Crear conexion
            Connection conn = DriverManager.getConnection(url, user, clave);
            // Statement
            Statement s = conn.createStatement();
            // Consulta
            String query = "SELECT * FROM usuario WHERE nick = '" + nick + "'";
            ResultSet rs = s.executeQuery(query);

            if (rs.next()) {
                if (rs.getString("contrasenya").equals(password)) {
                    usuario = UsuarioDAO.ResultSetToUser(rs);
                }
            }

            rs.close();
            s.close();
            conn.close();

        }

        return usuario;
    }

    private static Rol getRol(int id) throws SQLException {

        Rol rol = null;
        // Crear conexion
        Connection conn = DriverManager.getConnection(url, user, clave);
        // Statement
        Statement s = conn.createStatement();
        // Consulta
        String query = "SELECT * FROM rol WHERE id = " + id;
        ResultSet rs = s.executeQuery(query);

        if (rs.next()) {
            rol = new Rol();
            rol.setId(rs.getInt("id"));
            rol.setNombre(rs.getString("nombre"));
        }

        rs.close();
        s.close();
        conn.close();

        return rol;
    }

    public static Usuario ResultSetToUser(ResultSet rs) throws SQLException {

        Usuario u = new Usuario();
        u.setId(rs.getInt("id"));
        u.setDni(rs.getString("dni"));
        u.setNick(rs.getString("nick"));
        u.setContrasenya(rs.getString("contrasenya"));
        u.setNombre(rs.getString("nombre"));
        u.setApellidos(rs.getString("apellidos"));
        u.setTelefono(rs.getInt("telefono"));
        u.setPuntos(rs.getInt("puntos"));
        u.setRolId(UsuarioDAO.getRol(rs.getInt("rol_id")));

        return u;
    }

    //Alta de usuario
    public static boolean save(Usuario usuario) {

        UsuarioClient cliente = new UsuarioClient();
        if (usuario != null) {
            cliente.create_XML(usuario);
            return true;
        } else {
            return false;
        }
    }

    //Baja de usuario
    public static void delete(String id) {

        UsuarioClient cliente = new UsuarioClient();
        cliente.remove(id);

    }

    public static void update(Usuario usuario, String id) {

        UsuarioClient cliente = new UsuarioClient();
        cliente.edit_XML(usuario, id);

    }

    //obtener todos los usuarios desde el servicio web
    public static List<Usuario> getListado() {

        UsuarioClient cliente = new UsuarioClient();
        GenericType<List<Usuario>> tipoGenerico = new GenericType<List<Usuario>>() {
        };
        List<Usuario> datos = cliente.findAll_XML(tipoGenerico);

        return datos;
    }

    //obtener un usuario desde el servicio web
    public static Usuario getUser(String id) {

        UsuarioClient cliente = new UsuarioClient();
        GenericType<Usuario> tipoGenerico = new GenericType<Usuario>() {
        };
        return cliente.find_XML(tipoGenerico, id);
    }

}

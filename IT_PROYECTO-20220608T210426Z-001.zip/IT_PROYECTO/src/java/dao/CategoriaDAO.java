/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.CategoriaClient;
import java.util.List;
import entidades.Categoria;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author jucargoe
 */
public class CategoriaDAO {

    private static final String controlador = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/it_proyecto_g9?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String user = "root";
    private static final String clave = "";

    // Cargar driver controlador
    static {
        try {
            Class.forName(controlador);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Error loading JDBC Driver " + "class. Cause: " + ex);
        }
    }

    //obtener todas las categorias desde el servicio web
    public static List<Categoria> getListado() {

        CategoriaClient cliente = new CategoriaClient();

        GenericType<List<Categoria>> tipoGenerico = new GenericType<List<Categoria>>() {
        };
        List<Categoria> datos = cliente.findAll_XML(tipoGenerico);

        return datos;
    }

    //Alta de categoria
    public static boolean save(Categoria categoria) {

        CategoriaClient cliente = new CategoriaClient();
        if (categoria != null) {
            cliente.create_XML(categoria);
            return true;
        } else {
            return false;
        }
    }

    //Baja de categoria
    public static void delete(String id) {
        CategoriaClient cliente = new CategoriaClient();
        cliente.remove(id);
    }

    public static Categoria getCategory(String nombre) throws SQLException {
        
        Categoria c = new Categoria();
        // Crear conexion
        Connection conn = DriverManager.getConnection(url, user, clave);
        // Statement
        Statement s = conn.createStatement();
        // Consulta
        String query = "SELECT * FROM categoria WHERE nombre = '" + nombre + "'";
        ResultSet rs = s.executeQuery(query);

        if (rs.next()) {
            c.setId(rs.getInt("id"));
            c.setNombre(rs.getString("nombre"));
        }

        rs.close();
        s.close();
        conn.close();
        return c;
    }
}

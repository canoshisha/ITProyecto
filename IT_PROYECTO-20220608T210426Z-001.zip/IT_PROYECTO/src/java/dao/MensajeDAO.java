/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.MensajeClient;
import java.util.*;
import entidades.Mensaje;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author cutit
 */
public class MensajeDAO {

    public static List<Mensaje> getListado() {
        MensajeClient cliente = new MensajeClient();
        GenericType<List<Mensaje>> tipoGenerico = new GenericType<List<Mensaje>>() {
        };
        List<Mensaje> datos = cliente.findAll_XML(tipoGenerico);

        return datos;
    }
    
    public static List<Mensaje> msgTema(String id) {
        List<Mensaje> todos = getListado();
        List<Mensaje> msg = new ArrayList<>();
        for (Mensaje m : todos) {
            if (m.getTemaId().getId().equals(Integer.parseInt(id))){
                msg.add(m);
            }
        }
        return msg;
    }
    
    public static void crearMsg(Mensaje mensaje) {
        MensajeClient cliente = new MensajeClient();
        cliente.create_XML(mensaje);
    }

    public static void deleteMsg(String id) {
        MensajeClient cliente = new MensajeClient();
        cliente.remove(id);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.ProductoClient;
import entidades.Categoria;
import java.util.ArrayList;
import java.util.List;
import entidades.Producto;
import entidades.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author jucargoe
 */
public class ProductoDAO {

    private static final String controlador = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/it_proyecto_g9?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String user = "root";
    private static final String clave = "";

    // Cargar driver controlador
    static {
        try {
            Class.forName(controlador);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Error loading JDBC Driver " + "class. Cause: " + ex);
        }
    }

    //obtener todos los productos desde el servicio web
    public static List<Producto> getListado() {

        ProductoClient cliente = new ProductoClient();

        GenericType<List<Producto>> tipoGenerico = new GenericType<List<Producto>>() {
        };
        List<Producto> datos = cliente.findAll_XML(tipoGenerico);

        return datos;
    }

    public static List<Producto> getListadoFiltrado(String categoria) throws SQLException {
        if (categoria == null) {
            return getListado();
        } else {
            List<Producto> list = new ArrayList<>();
            // Crear conexion
            Connection conn = DriverManager.getConnection(url, user, clave);
            // Statement
            Statement s = conn.createStatement();
            // Consulta
            Categoria cat = CategoriaDAO.getCategory(categoria);
            String query = "SELECT * FROM producto WHERE categoria_id = '" + cat.getId() + "'";
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                Producto p = new Producto();
                p.setId(rs.getInt("id"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecio(rs.getDouble("precio"));
                p.setUrlImagen(rs.getString("url_imagen"));
                p.setComprado(rs.getBoolean("comprado"));
                p.setCategoriaId(cat);
                p.setUsuarioId(ProductoDAO.getUser(rs.getInt("usuario_id")));
                list.add(p);
            }

            rs.close();
            s.close();
            conn.close();

            return list;
        }
    }

    private static Usuario getUser(int id) throws SQLException {

        Usuario u = null;
        // Crear conexion
        Connection conn = DriverManager.getConnection(url, user, clave);
        // Statement
        Statement s = conn.createStatement();
        // Consulta
        String query = "SELECT * FROM usuario WHERE id = " + id;
        ResultSet rs = s.executeQuery(query);

        if (rs.next()) {
            u = UsuarioDAO.ResultSetToUser(rs);
        }

        rs.close();
        s.close();
        conn.close();

        return u;
    }

    public static boolean guardar(Producto producto) {

        ProductoClient cliente = new ProductoClient();
        if (producto != null) {
            cliente.create_XML(producto);
            return true;
        } else {
            return false;
        }
    }
    
    public static void delete(String id) {
        ProductoClient cliente = new ProductoClient();
        cliente.remove(id);
    }
    
    public static void update(Producto producto, String id) {

        ProductoClient cliente = new ProductoClient();
        cliente.edit_XML(producto, id);

    }

    //obtener un producto desde el servicio web
    public static Producto getProduct(String id) {

        ProductoClient cliente = new ProductoClient();
        GenericType<Producto> tipoGenerico = new GenericType<Producto>() {
        };
        return cliente.find_XML(tipoGenerico, id);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import cliente.ws.restful.RolClient;
import entidades.Rol;
import java.util.List;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author jucargoe
 */
public class RolDAO {

    //obtener todos los roles desde el servicio web
    public static List<Rol> getListado() {
        
        RolClient cliente = new RolClient();
        
        GenericType<List<Rol>> tipoGenerico = new GenericType<List<Rol>>(){};
        List<Rol> datos = cliente.findAll_XML(tipoGenerico);
        
        return datos;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionSupport;
import dao.UsuarioDAO;
import entidades.Rol;
import entidades.Usuario;
import java.util.List;

/**
 *
 * @author jucargoe
 */
public class RegistroAcciones extends ActionSupport {

    private int id, telefono, puntos, rol_id;
    private String dni, nick, contrasenya, nombre, apellidos;
    private List<Usuario> usuarios;

    public int getId() {
        return id;
    }

    public int getPuntos() {
        return puntos;
    }

    public int getRol_id() {
        return rol_id;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public RegistroAcciones() {
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    //alta usuario (Registro)
    public String guardar() {

        Usuario usuario = new Usuario();
        usuario.setNombre(this.getNombre());
        usuario.setApellidos(this.getApellidos());
        usuario.setDni(this.getDni());
        usuario.setContrasenya(this.getContrasenya());
        usuario.setTelefono(this.getTelefono());
        usuario.setNick(this.getNick());
        usuario.setPuntos(0);

        Rol rol = new Rol(1);
        usuario.setRolId(rol);

        UsuarioDAO.save(usuario);
        this.usuarios = UsuarioDAO.getListado();
        return SUCCESS;
    }
}

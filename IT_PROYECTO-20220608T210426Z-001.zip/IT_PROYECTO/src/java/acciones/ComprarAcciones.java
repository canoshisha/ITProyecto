/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import dao.ProductoDAO;
import dao.TransaccionDAO;
import dao.UsuarioDAO;
import java.util.ArrayList;
import java.util.List;
import entidades.Categoria;
import entidades.Producto;
import entidades.Usuario;
import java.sql.SQLException;

/**
 *
 * @author jucargoe
 */
public class ComprarAcciones extends ActionSupport {

    private List<Producto> productos;
    private List<String> categorias;
    private List<String> formasPago;
    private String id;
    private Producto producto;
    private String filtroCategoria;
    private String formaPago;
    private String direccion;

    public ComprarAcciones() {
    }

    public String getId() {
        return id;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getFiltroCategoria() {
        return filtroCategoria;
    }

    public void setFiltroCategoria(String filtroCategoria) {
        this.filtroCategoria = filtroCategoria;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public List<String> getCategorias() {
        List<Categoria> c = CategoriaDAO.getListado();
        List<String> nombre_categorias = new ArrayList<>();
        c.forEach((categoria) -> {
            nombre_categorias.add(categoria.getNombre());
        });
        return nombre_categorias;
    }

    public void setCategorias(List<String> categorias) {
        this.categorias = categorias;
    }

    //Lista Select formas de pago
    public List<String> getFormasPago() {
        List<String> formas_pago = new ArrayList<>();
        formas_pago.add("Bizum");
        formas_pago.add("Transferencia");
        formas_pago.add("Canjeo de puntos");
        return formas_pago;
    }

    public void setFormasPago(List<String> formasPago) {
        this.formasPago = formasPago;
    }

    public String execute() throws Exception {

        //obtener producto y comprarlo
        Producto p = ProductoDAO.getProduct(this.id);
        //Transaccion
        Usuario u = (Usuario) ActionContext.getContext().getSession().get("usuario");
        if (this.formaPago.equalsIgnoreCase("Canjeo de puntos")) {
            if (u.getPuntos() < p.getPuntos()) {
                //No tiene puntos suficientes
                return ERROR;
            } else {
                u.setPuntos(u.getPuntos() - p.getPuntos());
                UsuarioDAO.update(u, String.valueOf(u.getId()));
                //crear transaccion de compra por canjeo de puntos
                p.setComprado(true);
                Usuario vendedor = p.getUsuarioId();
                vendedor.setPuntos(vendedor.getPuntos() + p.getPuntos());
                UsuarioDAO.update(vendedor, String.valueOf(vendedor.getId()));
                ProductoDAO.update(p, this.id);
                TransaccionDAO.crearTransaccion(p, u, this.direccion, this.formaPago);
            }
        } else {
            //crear transaccion de compra
            p.setComprado(true);
            Usuario vendedor = p.getUsuarioId();
            vendedor.setPuntos(vendedor.getPuntos() + p.getPuntos());
            UsuarioDAO.update(vendedor, String.valueOf(vendedor.getId()));
            ProductoDAO.update(p, this.id);
            TransaccionDAO.crearTransaccion(p, u, this.direccion, this.formaPago);
        }
        return SUCCESS;
    }

    //Listado de productos
    public String listado() {
        this.productos = ProductoDAO.getListado();
        this.setCategorias(this.getCategorias());
        return SUCCESS;
    }

    //Ver Detalles producto
    public String ver() {
        this.producto = ProductoDAO.getProduct(this.id);
        if (this.getProducto() != null) {
            return SUCCESS;
        } else {
            this.listado();
            return ERROR;
        }
    }

    //Filtro de productos por categoria
    public String filtrar() throws SQLException {
        this.categorias = this.getCategorias();
        if (this.getFiltroCategoria() == null) {
            this.productos = ProductoDAO.getListado();
        } else {
            this.productos = ProductoDAO.getListadoFiltrado(this.getFiltroCategoria());
        }

        return SUCCESS;
    }

    //Borrar el filtro
    public String removeFilter() {
        this.categorias = this.getCategorias();
        this.productos = ProductoDAO.getListado();
        return SUCCESS;
    }

}

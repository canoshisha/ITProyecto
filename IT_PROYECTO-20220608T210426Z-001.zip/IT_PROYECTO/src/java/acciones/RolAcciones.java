/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionSupport;
import dao.RolDAO;
import java.util.List;
import entidades.Rol;

/**
 *
 * @author jucargoe
 */
public class RolAcciones extends ActionSupport {

    private List<Rol> roles;

    public RolAcciones() {
    }

    public List<Rol> getRoles() {
        return roles;
    }

    public String execute() throws Exception {
        this.roles = RolDAO.getListado();
        return SUCCESS;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import dao.ProductoDAO;
import entidades.Categoria;
import java.util.List;
import entidades.Producto;
import entidades.Usuario;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.commons.io.FileUtils;
import static org.apache.struts2.ServletActionContext.getServletContext;

/**
 *
 * @author jucargoe
 */
public class ProductoAcciones extends ActionSupport {

    private List<Producto> productos;
    private List<String> categorias;
    private String descripcion;
    private boolean comprado;
    private int puntos;
    private double precio;
    private String categoria;
    private String id;
    private File imagen;
    private String imagenFileName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setCategorias(List<String> categorias) {
        this.categorias = categorias;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public List<String> getCategorias() {
        List<Categoria> c = CategoriaDAO.getListado();
        List<String> nombre_categorias = new ArrayList<>();
        c.forEach((categoria) -> {
            nombre_categorias.add(categoria.getNombre());
        });
        return nombre_categorias;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setComprado(boolean comprado) {
        this.comprado = comprado;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public File getImagen() {
        return imagen;
    }

    public void setImagen(File imagen) {
        this.imagen = imagen;
    }

    public String getImagenFileName() {
        return imagenFileName;
    }

    public void setImagenFileName(String imagenFileName) {
        this.imagenFileName = imagenFileName;
    }

    public boolean isComprado() {
        return comprado;
    }

    public int getPuntos() {
        return puntos;
    }

    public double getPrecio() {
        return precio;
    }

    public ProductoAcciones() {
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public String execute() throws Exception {
        this.productos = ProductoDAO.getListado();
        return SUCCESS;
    }

    public String subirProducto() throws SQLException, IOException {

        String ruta = splitURL() + "web\\imagenes\\productos\\";
        String nombre_Imagen = this.imagenFileName;
        try {
            File f = new File(ruta + nombre_Imagen);
            FileUtils.copyFile(this.imagen, f);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        Producto p = new Producto();
        p.setComprado(false);
        p.setDescripcion(this.descripcion);
        p.setPrecio(this.precio);
        p.setPuntos(this.puntos);
        Usuario u = (Usuario) ActionContext.getContext().getSession().get("usuario");
        p.setUsuarioId(u);
        p.setCategoriaId(CategoriaDAO.getCategory(this.categoria));
        p.setUrlImagen(nombre_Imagen);

        ProductoDAO.guardar(p);

        this.productos = ProductoDAO.getListado();
        return SUCCESS;
    }

    //obtencion de la URL del proyecto para almacenar los archivos
    private String splitURL() {
        String[] arrayStr = getServletContext().getRealPath("/").split("build");
        return arrayStr[0];
    }

    public String deleteProduct() {
        ProductoDAO.delete(this.id);
        this.categorias = this.getCategorias();
        this.productos = ProductoDAO.getListado();
        return SUCCESS;
    }

    public String modificarProducto() throws SQLException {

        Producto p = ProductoDAO.getProduct(this.id);
        if (this.imagenFileName != null) {
            String ruta = splitURL() + "web\\imagenes\\productos\\";
            String nombre_Imagen = this.imagenFileName;
            try {
                File f = new File(ruta + nombre_Imagen);
                FileUtils.copyFile(this.imagen, f);
                p.setUrlImagen(nombre_Imagen);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        p.setDescripcion(this.descripcion);
        p.setPrecio(this.precio);
        p.setPuntos(this.puntos);
        p.setCategoriaId(CategoriaDAO.getCategory(this.categoria));
        p.setComprado(p.getComprado());
        p.setUsuarioId(p.getUsuarioId());

        ProductoDAO.update(p, this.id);
        this.productos = ProductoDAO.getListado();
        return SUCCESS;
    }
}

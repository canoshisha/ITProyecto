/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import dao.TemaDAO;
import entidades.Categoria;
import java.util.List;
import entidades.Tema;
import entidades.Usuario;
import java.sql.SQLException;

/**
 *
 * @author jucargoe
 */
public class TemaAcciones extends ActionSupport {

    private String titulo;
    private String categoria;
    private List<Tema> temas;
    private int categoria_id;

    public int getCategoria_id() {
        return categoria_id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setCategoria_id(int categoria_id) {
        this.categoria_id = categoria_id;
    }

    public TemaAcciones() {
    }

    public List<Tema> getTemas() {
        return temas;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String execute() throws Exception {
        this.temas = TemaDAO.getListado();
        return SUCCESS;
    }

    public String nuevoTema() throws SQLException {
        Tema t = new Tema();
        t.setTitulo(this.getTitulo());
        Categoria cat = CategoriaDAO.getCategory(this.categoria);
        t.setCategoriaId(cat);
        //usuario de sesion crea el tema
        Usuario user = (Usuario) ActionContext.getContext().getSession().get("usuario");
        t.setUsuarioId(user);
        TemaDAO.save(t);
        this.temas = TemaDAO.getListado();
        return SUCCESS;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionSupport;
import dao.UsuarioDAO;
import java.util.List;
import entidades.Usuario;

/**
 *
 * @author jucargoe
 */
public class ListadoUsuarioAcciones extends ActionSupport {

    private List<Usuario> usuarios;

    public ListadoUsuarioAcciones() {
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public String execute() throws Exception {
        this.usuarios = UsuarioDAO.getListado();
        return SUCCESS;

    }

}

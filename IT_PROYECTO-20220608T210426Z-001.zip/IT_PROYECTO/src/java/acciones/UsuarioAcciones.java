/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.RolDAO;
import dao.UsuarioDAO;
import entidades.Rol;
import entidades.Usuario;
import java.util.List;

/**
 *
 * @author jucargoe
 */
public class UsuarioAcciones extends ActionSupport {

    private int telefono, puntos, rol_id;
    private String id;
    private String dni, nick, contrasenya, nombre, apellidos;
    private List<Usuario> usuarios;
    private String rol;
    private List<Rol> roles;

    public List<Rol> getRoles() {
        return roles;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public UsuarioAcciones() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getRol_id() {
        return rol_id;
    }

    public void setRol_id(int rol_id) {
        this.rol_id = rol_id;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String execute() throws Exception {

        Usuario usuario = UsuarioDAO.getUser(this.id);

        usuario.setNombre(this.getNombre());
        usuario.setApellidos(this.getApellidos());
        usuario.setDni(this.getDni());
        usuario.setNick(this.getNick());
        usuario.setContrasenya(this.getContrasenya());
        usuario.setTelefono(this.getTelefono());
        
        List<Rol> roles = RolDAO.getListado();
        for (Rol r : roles){
            if (r.getNombre().equals(this.rol)){
                usuario.setRolId(r);
            }
        }
        UsuarioDAO.update(usuario, this.id);
        ActionContext.getContext().getSession().put("usuario", usuario);
        return SUCCESS;

    }

    public String modifyUser() {

        Usuario usuario = UsuarioDAO.getUser(this.id);

        usuario.setNombre(this.getNombre());
        usuario.setApellidos(this.getApellidos());
        usuario.setDni(this.getDni());
        usuario.setNick(this.getNick());
        usuario.setTelefono(this.getTelefono());
        usuario.setContrasenya(this.getContrasenya());

        List<Rol> roles = RolDAO.getListado();
        for (Rol r : roles){
            if (r.getNombre().equals(this.rol)){
                usuario.setRolId(r);
            }
        }
        
        if (usuario.getRolId().getNombre().equalsIgnoreCase("administrador")){
            usuario.setPuntos(puntos);
        }
        
        UsuarioDAO.update(usuario, this.id);
        this.usuarios = UsuarioDAO.getListado();
        return SUCCESS;
    }

    //alta usuario
    public String guardar() {

        Usuario usuario = new Usuario();
        usuario.setNombre(this.getNombre());
        usuario.setApellidos(this.getApellidos());
        usuario.setDni(this.getDni());
        usuario.setContrasenya(this.getContrasenya());
        usuario.setTelefono(this.getTelefono());
        usuario.setNick(this.getNick());
        usuario.setPuntos(0);

        Rol rol = new Rol(1);
        usuario.setRolId(rol);

        UsuarioDAO.save(usuario);
        this.usuarios = UsuarioDAO.getListado();
        return SUCCESS;
    }

}

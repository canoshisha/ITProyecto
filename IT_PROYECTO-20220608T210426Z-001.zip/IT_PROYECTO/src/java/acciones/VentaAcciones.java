/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import dao.ProductoDAO;
import java.util.ArrayList;
import java.util.List;
import entidades.Categoria;
import entidades.Producto;

/**
 *
 * @author jucargoe
 */
public class VentaAcciones extends ActionSupport {

    private List<Producto> productos;
    private List<String> categorias;
    private List<String> formasPago;
    private String id;
    private Producto producto;
    private String formaPago;

    public VentaAcciones() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public List<String> getCategorias() {
        List<Categoria> categorias = CategoriaDAO.getListado();
        List<String> nombre_categorias = new ArrayList<>();
        categorias.forEach((categoria) -> {
            nombre_categorias.add(categoria.getNombre());
        });
        return nombre_categorias;
    }

    public void setCategorias(List<String> categorias) {
        this.categorias = categorias;
    }

    public String execute() throws Exception {
       this.setProductos(ProductoDAO.getListado());
        this.setCategorias(this.getCategorias());
        return SUCCESS;
    }


    public String ver() throws Exception {
        this.setProducto(ProductoDAO.getProduct(this.getId()));
        if (this.getProducto() != null) {
            return SUCCESS;
        } else {
            this.execute();
            return ERROR;
        }
    }


}

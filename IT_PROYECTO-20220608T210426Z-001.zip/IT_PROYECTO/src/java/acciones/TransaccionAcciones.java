/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.TransaccionDAO;
import java.util.List;
import java.util.Map;
import entidades.Transacciones;
import entidades.Usuario;

/**
 *
 * @author jucargoe
 */
public class TransaccionAcciones extends ActionSupport {

    private List<Transacciones> transacciones;

    public TransaccionAcciones() {
    }

    public List<Transacciones> getTransacciones() {
        return transacciones;
    }

    public void setTransacciones(List<Transacciones> transacciones) {
        this.transacciones = transacciones;
    }

    public String execute() throws Exception {
        Map session = (Map) ActionContext.getContext().getSession();
        Usuario usuario = (Usuario) session.get("usuario");
        this.transacciones = TransaccionDAO.getListado(usuario.getId());
        return SUCCESS;

    }

}

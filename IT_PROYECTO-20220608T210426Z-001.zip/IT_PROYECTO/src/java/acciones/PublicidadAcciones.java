/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.PublicidadDAO;
import java.util.List;
import entidades.Publicidad;
import entidades.Usuario;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import static org.apache.struts2.ServletActionContext.getServletContext;

/**
 *
 * @author jucargoe
 */
public class PublicidadAcciones extends ActionSupport {

    private List<Publicidad> publicidades;
    private String enlace;
    private String imagen;
    private String id;
    private File file_img;
    private String file_imgFileName; //nombre de la imagen

    public String getFile_imgFileName() {
        return file_imgFileName;
    }

    public List<Publicidad> getPublicidades() {
        return publicidades;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public File getFile_img() {
        return file_img;
    }

    public void setFile_imgFileName(String file_imgFileName) {
        this.file_imgFileName = file_imgFileName;
    }

    public void setFile_img(File file_img) {
        this.file_img = file_img;
    }

    public String getEnlace() {
        return enlace;
    }

    public String getImagen() {
        return imagen;
    }

    public void setEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String execute() throws Exception {
        this.publicidades = PublicidadDAO.getListado();
        return SUCCESS;
    }

    public String getUploadFileName() {
        return file_imgFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.file_imgFileName = uploadFileName;
    }

    //obtencion de la URL del proyecto para almacenar los archivos
    private String splitURL() {
        String[] arrayStr = getServletContext().getRealPath("/").split("build");
        return arrayStr[0];
    }
    
    public String deletePublicidad() {
        PublicidadDAO.delete(this.id);
        this.publicidades = PublicidadDAO.getListado();
        return SUCCESS;
    }

    public String createPublicidad() throws FileNotFoundException, IOException {

        String ruta = splitURL() + "web\\imagenes\\anuncios\\";
        String nombre_Imagen = this.file_imgFileName;
        try {
            File f = new File(ruta + nombre_Imagen);
            FileUtils.copyFile(file_img, f);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        //crear nueva publicidad
        Publicidad p = new Publicidad();
        p.setImagen(nombre_Imagen);
        Usuario u = (Usuario) ActionContext.getContext().getSession().get("usuario");
        p.setUsuaioId(u);
        p.setEnlace(this.enlace);
        //coste de publicar el anuncio
        float coste = 55 + (u.getId() + (50 - u.getPuntos()));
        if (coste < 0){
            coste = 55;
        }
        p.setCoste(coste);

        PublicidadDAO.save(p);

        this.publicidades = PublicidadDAO.getListado();
        return SUCCESS;
    }
}

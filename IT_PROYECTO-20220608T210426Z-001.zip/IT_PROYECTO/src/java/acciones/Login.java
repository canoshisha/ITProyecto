/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.validator.annotations.*;
import dao.UsuarioDAO;
import entidades.Usuario;

/**
 *
 * @author jucargoe
 */
public class Login extends ActionSupport {

    private String nick, password;

    public Login() {
    }

    public String getNick() {
        return nick;
    }

    @RequiredStringValidator(key = "nick.required")
    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getPassword() {
        return password;
    }

    @RequiredStringValidator(key = "password.required")
    public void setPassword(String password) {
        this.password = password;
    }

    public String execute() throws Exception {
        Usuario usuario = UsuarioDAO.login(this.getNick(), this.getPassword());
        if (usuario != null) {
            ActionContext.getContext().getSession().put("usuario", usuario);
            return SUCCESS;
        } else {
            return ERROR;
        }
    }

    public String logout() throws Exception {
        ActionContext.getContext().getSession().clear();
        return SUCCESS;
    }
}

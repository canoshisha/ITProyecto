/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import dao.ProductoDAO;
import dao.RolDAO;
import dao.TemaDAO;
import dao.UsuarioDAO;
import java.util.List;
import entidades.Categoria;
import entidades.Producto;
import entidades.Rol;
import entidades.Tema;
import entidades.Usuario;
import java.io.File;
import java.sql.SQLException;

/**
 *
 * @author cutit
 */
public class Acciones extends ActionSupport {

    private List<Categoria> categorias;
    private List<Tema> temas;
    private List<Usuario> usuarios;
    private String tema;
    private String id;
    private Usuario usuario;
    private List<Rol> roles;
    private String descripcion;
    private float precio;
    private int puntos;
    private String categoria;
    private File imagen;
    Producto producto;

    public Acciones() {
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public File getImagen() {
        return imagen;
    }

    public void setImagen(File imagen) {
        this.imagen = imagen;
    }

    public List<Rol> getRoles() {
        return roles;
    }
    
    public List<Categoria> getCategorias() {
        return categorias;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public List<Tema> getTemas() {
        return temas;
    }

    public String getTema() {
        return tema;
    }

    public String getId() {
        return id;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public String execute() throws Exception {
        return SUCCESS;
    }

    public String mainMenu() {
        return SUCCESS;
    }

    //Cerrar Sesion
    public String logout() throws Exception {
        ActionContext.getContext().getSession().clear();
        return SUCCESS;
    }

    public String listadoCategoria() {
        this.categorias = CategoriaDAO.getListado();
        return SUCCESS;
    }

    public String listadoTemas() {
        this.temas = TemaDAO.getListado();
        return SUCCESS;
    }

    public String cargarFormCategoria() {
        return SUCCESS;
    }

    public String cargarFormPublicidad() {
        return SUCCESS;
    }

    //Formulario Modificar Usuario
    public String cargarFormUsuario() {
        
        this.roles = RolDAO.getListado();
        
        Rol r = UsuarioDAO.getUser(this.id).getRolId();
        this.roles.remove(r);
        
        this.usuario = UsuarioDAO.getUser(id);
        return SUCCESS;
    }

    public String cargarFormProducto() throws SQLException {
        producto = ProductoDAO.getProduct(this.id);
        
        this.categorias = CategoriaDAO.getListado();
        
        Categoria c = CategoriaDAO.getCategory(this.producto.getCategoriaId().getNombre());
        this.categorias.remove(c);
        
        return SUCCESS;
    }

    public String cargarFormForo() {
        this.temas = TemaDAO.getListado();
        this.categorias = CategoriaDAO.getListado();
        return SUCCESS;
    }

    public String deleteTema() throws SQLException {
        TemaDAO.delete(this.id);
        this.temas = TemaDAO.getListado();
        return SUCCESS;
    }

    public String deleteCategory() {
        CategoriaDAO.delete(this.id);
        this.categorias = CategoriaDAO.getListado();
        return SUCCESS;
    }

    //baja de Usuario
    public String deleteUser() {
        UsuarioDAO.delete(this.id);
        this.usuarios = UsuarioDAO.getListado();
        return SUCCESS;
    }

    public String getRolesMicuenta() {

        this.roles = RolDAO.getListado();
        Usuario sessionUser = (Usuario) ActionContext.getContext().getSession().get("usuario");

        if (!sessionUser.getRolId().getNombre().equalsIgnoreCase("Administrador")) {
            this.roles.remove(2);
        }
        
        Rol r = sessionUser.getRolId();
        this.roles.remove(r);

        return SUCCESS;
    }

    public String cargarFormSubirProducto() {
        this.categorias = CategoriaDAO.getListado();
        return SUCCESS;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import dao.MensajeDAO;
import dao.TemaDAO;
import java.util.List;
import entidades.Mensaje;
import entidades.Usuario;
import java.util.Date;

/**
 *
 * @author jucargoe
 */
public class MensajeAcciones extends ActionSupport {

    private List<Mensaje> mensajes;
    private String id;
    private String tema;
    private String mensaje;
    private String idTema;

    public String getIdTema() {
        return idTema;
    }

    public void setIdTema(String idTema) {
        this.idTema = idTema;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getTema() {
        return tema;
    }

    public void setMensajes(List<Mensaje> mensajes) {
        this.mensajes = mensajes;
    }
    
    public void setTema(String tema) {
        this.tema = tema;
    }

    public MensajeAcciones() {
    }

    public List<Mensaje> getMensajes() {
        return mensajes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String execute() throws Exception {
        this.tema = TemaDAO.getTema(this.id).getTitulo();
        this.mensajes = MensajeDAO.msgTema(this.id);
        return SUCCESS;
    }

    public String escribirMensaje() {
        Mensaje msg = new Mensaje();
        msg.setContenido(this.getMensaje());
        msg.setFecha(new Date());
        msg.setTemaId(TemaDAO.getTema(this.id));
        Usuario u = (Usuario) ActionContext.getContext().getSession().get("usuario");
        msg.setUsuarioId(u);
        MensajeDAO.crearMsg(msg);
        
        this.tema = TemaDAO.getTema(this.id).getTitulo();
        this.mensajes = MensajeDAO.msgTema(this.id);
        this.setMensaje("");
        return SUCCESS;
    }
    
    public String deleteMensaje() {
        MensajeDAO.deleteMsg(this.id);
        this.tema = TemaDAO.getTema(this.idTema).getTitulo();
        this.mensajes = MensajeDAO.msgTema(this.idTema);
        return SUCCESS;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acciones;

import com.opensymphony.xwork2.ActionSupport;
import dao.CategoriaDAO;
import java.util.List;
import entidades.Categoria;

/**
 *
 * @author jucargoe
 */
public class CategoriaAcciones extends ActionSupport {

    private String nombre;
    private String id;
    private List<Categoria> categorias;

    public CategoriaAcciones() {
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String execute() throws Exception {
        Categoria c = new Categoria();
        c.setNombre(this.getNombre());
        CategoriaDAO.save(c);
        this.categorias = CategoriaDAO.getListado();
        return SUCCESS;
    }

}

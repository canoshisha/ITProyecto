/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import DAO.BizumDAO;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.bind.annotation.XmlSeeAlso;
import persistencia.Bizum;
import persistencia.Central;

@WebService(serviceName = "BizumWS")

public class BizumWS {

    @WebMethod(operationName = "listarBizum")
    public List<Central> listarBizum() {
        BizumDAO bizum = new BizumDAO();
        return  bizum.listarBizum();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.ArrayList;
import java.util.List;
import modelo.HibernateUtil;
import modelo.Prestamo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author alvip
 */
public class PrestamoDAO {

    List<Prestamo> prestamo = new ArrayList();

    public List<Prestamo> listar() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction t = s.beginTransaction();
        Query q = s.createQuery("from Prestamo");
        prestamo = q.list();
        t.commit();
        s.close();
        return prestamo;

    }

    public String consultarPrestamo(int id) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        Transaction t = s.beginTransaction();
        
        Prestamo p =(Prestamo)s.get(Prestamo.class, id);
        s.close();
        
        if(p!= null){
            return "El producto de codigo"+p.getCuentaBancaria();
        }else{
            return "El producto no existe";
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import DAO.PrestamoDAO;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.ejb.Stateless;
import javax.jws.WebParam;
import javax.xml.bind.annotation.XmlSeeAlso;
import modelo.HibernateUtil;
import modelo.Prestamo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author alvip
 */
@WebService(serviceName = "PrestamoSOAP")
@XmlSeeAlso(Prestamo.class)
public class PrestamoSOAP {

    @WebMethod(operationName = "consultarPrestamo")
    public List<Prestamo> consultarPrestamo() {
        PrestamoDAO prestamodao = new PrestamoDAO();
        List<Prestamo> listadoPrestamo = prestamodao.listar();
   
        return listadoPrestamo;
    }

    @WebMethod(operationName = "buscarPrestamo")
    public String buscarPrestamo(@WebParam(name = "id") int id) {
        PrestamoDAO prestamodao = new PrestamoDAO();
        return prestamodao.consultarPrestamo(id);
    }
}
